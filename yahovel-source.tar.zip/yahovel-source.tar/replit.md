# YAHOVEL — Universal Marketplace

A Ghana-focused universal marketplace web app where people buy and sell anything (electronics, fashion, food, services, vehicles, real estate, etc.) and where moto/car owners can also operate as live delivery riders.

## Architecture

- **Monorepo**: pnpm workspace with three artifacts:
  - `artifacts/yahovel` — React + Vite frontend (web app, mounted at `/`)
  - `artifacts/api-server` — Express 5 + Drizzle backend (mounted at `/api`)
  - `artifacts/mockup-sandbox` — Canvas component sandbox (unused for this build)
- **Database**: PostgreSQL (Replit-managed) with Drizzle ORM. Schema in `lib/db/src/schema/`.
- **API contract**: OpenAPI 3 in `lib/api-spec/openapi.yaml` → Orval generates React Query hooks (`@workspace/api-client-react`) and Zod validators (`@workspace/api-zod`).
- **Auth**: Session-based — bcryptjs password hashes, opaque session tokens stored in `sessions` table, `httpOnly` cookie. Email, phone, and username are all UNIQUE in the DB and the `/auth/check` endpoint powers real-time availability checks during signup.
- **Map**: Leaflet + react-leaflet with OpenStreetMap tiles. Online riders polled every 15s.

## Key features

- Signup blocks duplicate email / phone / username via DB constraints + 409 responses.
- Product feed sorts: active boosters first → premium tier (diamond > gold > silver > basic > free) → distance (when nearby is on) → newest.
- Search ranks premium sellers first.
- "Near me" geolocation toggle filters and sorts by distance (Haversine).
- Riders go online from `/riders` or `/profile`; their live location is broadcast and shown on the map with vehicle-colored markers (moto = blue, car = orange, bicycle = green, truck = purple).
- Premium tiers (free / basic / silver / gold / diamond) activated via mock `/users/me/upgrade`.
- Theme: dark (black + electric blue) by default; light (white + electric blue) optional. Persisted on user record (`themePreference`) and falls back to localStorage when logged out.
- In-app chat: buyers tap "Message Seller" on a product to open a 1-on-1 conversation tied to that product. Inbox at `/messages`, conversation at `/messages/:chatId`, polled every 3-5s. Header shows an unread badge (polled every 10s). Messages are auto-marked as read when the recipient opens the thread. Schema: `chats` (`userAId < userBId` canonical pair, optional `productId`, unique on the triple) and `messages` (chat_id, sender_id, body, read_at).

## Demo accounts (password: `password123`)

- `akosua` — diamond tier, verified, Accra
- `kwame` — gold tier, verified, Kumasi
- `ama` — silver tier, verified, Accra
- `yaw` — free tier, currently online as a moto rider in Accra
- `esi` — basic tier, currently online as a car rider in Accra

## Common commands

```bash
pnpm --filter @workspace/api-spec run codegen      # regenerate hooks/zod after spec edit
pnpm --filter @workspace/db run push               # sync DB schema
pnpm --filter @workspace/api-server run typecheck  # check server types
pnpm run typecheck                                 # full workspace typecheck
```

## Notes for future edits

- All API hooks are imported from `@workspace/api-client-react`. Do not call `fetch` directly from the frontend.
- Server routes validate inputs and outputs with the generated Zod schemas in `@workspace/api-zod`.
- The `req.user` Express type is augmented in `artifacts/api-server/src/lib/auth.ts` (declared into `express-serve-static-core`).
- Do NOT use emojis in the UI.
