import { Router, type IRouter } from "express";
import { eq, desc, ilike, and, or, inArray } from "drizzle-orm";
import {
  db,
  productsTable,
  usersTable,
  type ProductRow,
  type UserRow,
} from "@workspace/db";
import {
  CreateProductBody,
  ListProductsQueryParams,
  GetProductParams,
  DeleteProductParams,
  BoostProductParams,
  BoostProductBody,
} from "@workspace/api-zod";
import { requireAuth } from "../lib/auth";
import {
  serializeProduct,
  distanceKm,
  tierRank,
} from "../lib/serialize";

const router: IRouter = Router();

router.get("/products", async (req, res): Promise<void> => {
  const parsed = ListProductsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { search, category, lat, lng, radiusKm } = parsed.data;
  const conditions = [];
  if (search) {
    const q = `%${search}%`;
    conditions.push(
      or(
        ilike(productsTable.title, q),
        ilike(productsTable.description, q),
        ilike(productsTable.category, q),
        ilike(productsTable.city, q),
      ),
    );
  }
  if (category) conditions.push(eq(productsTable.category, category));

  const where = conditions.length ? and(...conditions) : undefined;
  const productsRaw = await db
    .select()
    .from(productsTable)
    .where(where)
    .orderBy(desc(productsTable.createdAt))
    .limit(500);

  const sellerIds = Array.from(new Set(productsRaw.map((p) => p.sellerId)));
  const sellers = sellerIds.length
    ? await db
        .select()
        .from(usersTable)
        .where(inArray(usersTable.id, sellerIds))
    : [];
  const sellerMap = new Map<string, UserRow>(sellers.map((s) => [s.id, s]));

  const now = Date.now();
  const enriched: Array<{ p: ProductRow; seller: UserRow; dist: number | null }> = [];
  for (const p of productsRaw) {
    const seller = sellerMap.get(p.sellerId);
    if (!seller) continue;
    let dist: number | null = null;
    if (lat != null && lng != null && p.lat != null && p.lng != null) {
      dist = distanceKm(lat, lng, p.lat, p.lng);
      if (radiusKm != null && dist > radiusKm) continue;
    }
    enriched.push({ p, seller, dist });
  }

  enriched.sort((a, b) => {
    const aBoost =
      a.p.isBoosted &&
      a.p.boostedUntil != null &&
      a.p.boostedUntil.getTime() > now
        ? 1
        : 0;
    const bBoost =
      b.p.isBoosted &&
      b.p.boostedUntil != null &&
      b.p.boostedUntil.getTime() > now
        ? 1
        : 0;
    if (aBoost !== bBoost) return bBoost - aBoost;
    const aTier = tierRank(
      (a.seller.premiumTier as "free" | "basic" | "silver" | "gold" | "diamond") ??
        "free",
    );
    const bTier = tierRank(
      (b.seller.premiumTier as "free" | "basic" | "silver" | "gold" | "diamond") ??
        "free",
    );
    if (aTier !== bTier) return bTier - aTier;
    if (a.dist != null && b.dist != null && a.dist !== b.dist)
      return a.dist - b.dist;
    return b.p.createdAt.getTime() - a.p.createdAt.getTime();
  });

  res.json({
    products: enriched.map(({ p, seller, dist }) =>
      serializeProduct(p, seller, dist),
    ),
  });
});

router.post("/products", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateProductBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const data = parsed.data;
  const [created] = await db
    .insert(productsTable)
    .values({
      sellerId: req.user!.id,
      title: data.title,
      description: data.description,
      price: data.price,
      currency: data.currency ?? "GHS",
      category: data.category,
      condition: data.condition ?? "new",
      images: data.images ?? [],
      city: data.city ?? req.user!.city ?? null,
      lat: data.lat ?? req.user!.lat ?? null,
      lng: data.lng ?? req.user!.lng ?? null,
    })
    .returning();
  res.json(serializeProduct(created, req.user!));
});

router.get(
  "/products/mine",
  requireAuth,
  async (req, res): Promise<void> => {
    const products = await db
      .select()
      .from(productsTable)
      .where(eq(productsTable.sellerId, req.user!.id))
      .orderBy(desc(productsTable.createdAt));
    res.json({
      products: products.map((p) => serializeProduct(p, req.user!)),
    });
  },
);

router.get("/products/:productId", async (req, res): Promise<void> => {
  const params = GetProductParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const { productId } = params.data;
  const [row] = await db
    .select({ p: productsTable, seller: usersTable })
    .from(productsTable)
    .innerJoin(usersTable, eq(usersTable.id, productsTable.sellerId))
    .where(eq(productsTable.id, productId))
    .limit(1);
  if (!row) {
    res.status(404).json({ error: "Product not found" });
    return;
  }
  await db
    .update(productsTable)
    .set({ viewCount: row.p.viewCount + 1 })
    .where(eq(productsTable.id, productId));
  res.json(serializeProduct(row.p, row.seller));
});

router.delete(
  "/products/:productId",
  requireAuth,
  async (req, res): Promise<void> => {
    const params = DeleteProductParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const result = await db
      .delete(productsTable)
      .where(
        and(
          eq(productsTable.id, params.data.productId),
          eq(productsTable.sellerId, req.user!.id),
        ),
      )
      .returning({ id: productsTable.id });
    if (result.length === 0) {
      res.status(404).json({ error: "Not found" });
      return;
    }
    res.json({ ok: true });
  },
);

router.post(
  "/products/:productId/boost",
  requireAuth,
  async (req, res): Promise<void> => {
    const params = BoostProductParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const body = BoostProductBody.safeParse(req.body);
    if (!body.success) {
      res.status(400).json({ error: body.error.message });
      return;
    }
    const until = new Date(Date.now() + body.data.durationHours * 3600_000);
    const [updated] = await db
      .update(productsTable)
      .set({ isBoosted: true, boostedUntil: until })
      .where(
        and(
          eq(productsTable.id, params.data.productId),
          eq(productsTable.sellerId, req.user!.id),
        ),
      )
      .returning();
    if (!updated) {
      res.status(404).json({ error: "Not found" });
      return;
    }
    res.json(serializeProduct(updated, req.user!));
  },
);

export default router;
