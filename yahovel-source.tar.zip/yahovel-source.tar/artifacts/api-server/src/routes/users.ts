import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, usersTable, productsTable } from "@workspace/db";
import {
  UpdateMeBody,
  UpgradePlanBody,
  GetUserPublicParams,
} from "@workspace/api-zod";
import { requireAuth } from "../lib/auth";
import { serializeUser, serializeProduct } from "../lib/serialize";

const router: IRouter = Router();

router.patch("/users/me", requireAuth, async (req, res): Promise<void> => {
  const parsed = UpdateMeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const data = parsed.data;
  const update: Record<string, unknown> = {};
  if (data.name !== undefined) update.name = data.name;
  if (data.bio !== undefined) update.bio = data.bio;
  if (data.profilePicUrl !== undefined)
    update.profilePicUrl = data.profilePicUrl;
  if (data.city !== undefined) update.city = data.city;
  if (data.lat !== undefined) update.lat = data.lat;
  if (data.lng !== undefined) update.lng = data.lng;
  if (data.themePreference !== undefined)
    update.themePreference = data.themePreference;

  const [updated] = await db
    .update(usersTable)
    .set(update)
    .where(eq(usersTable.id, req.user!.id))
    .returning();
  res.json(serializeUser(updated));
});

router.post(
  "/users/me/upgrade",
  requireAuth,
  async (req, res): Promise<void> => {
    const parsed = UpgradePlanBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }
    const { tier } = parsed.data;
    const expires =
      tier === "free"
        ? null
        : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
    const [updated] = await db
      .update(usersTable)
      .set({ premiumTier: tier, premiumExpiresAt: expires })
      .where(eq(usersTable.id, req.user!.id))
      .returning();
    res.json(serializeUser(updated));
  },
);

router.get("/users/:userId", async (req, res): Promise<void> => {
  const params = GetUserPublicParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const { userId } = params.data;
  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, userId))
    .limit(1);
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  const products = await db
    .select()
    .from(productsTable)
    .where(eq(productsTable.sellerId, userId))
    .orderBy(desc(productsTable.createdAt));
  res.json({
    user: serializeUser(user),
    products: products.map((p) => serializeProduct(p, user)),
  });
});

export default router;
