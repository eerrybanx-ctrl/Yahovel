import { Router, type IRouter } from "express";
import { eq, and, or, desc, asc, inArray, sql, isNull } from "drizzle-orm";
import {
  db,
  chatsTable,
  messagesTable,
  usersTable,
  productsTable,
  type ChatRow,
  type MessageRow,
  type UserRow,
  type ProductRow,
} from "@workspace/db";
import {
  OpenChatBody,
  ListMessagesParams,
  SendMessageParams,
  SendMessageBody,
} from "@workspace/api-zod";
import { requireAuth } from "../lib/auth";

const router: IRouter = Router();

function tier(value: string): "free" | "basic" | "silver" | "gold" | "diamond" {
  const allowed = ["free", "basic", "silver", "gold", "diamond"] as const;
  return (allowed as readonly string[]).includes(value)
    ? (value as (typeof allowed)[number])
    : "free";
}

function serializeMessage(m: MessageRow) {
  return {
    id: m.id,
    chatId: m.chatId,
    senderId: m.senderId,
    body: m.body,
    readAt: m.readAt ? m.readAt.toISOString() : null,
    createdAt: m.createdAt.toISOString(),
  };
}

function serializePeer(u: UserRow) {
  return {
    id: u.id,
    name: u.name,
    username: u.username,
    profilePicUrl: u.profilePicUrl,
    premiumTier: tier(u.premiumTier),
    isVerified: u.isVerified,
  };
}

function serializeProduct(p: ProductRow) {
  return {
    id: p.id,
    title: p.title,
    price: p.price,
    currency: p.currency,
    image: p.images?.[0] ?? null,
  };
}

function orderPair(a: string, b: string): [string, string] {
  return a < b ? [a, b] : [b, a];
}

router.get("/chats", requireAuth, async (req, res): Promise<void> => {
  const me = req.user!.id;
  const chats = await db
    .select()
    .from(chatsTable)
    .where(or(eq(chatsTable.userAId, me), eq(chatsTable.userBId, me)))
    .orderBy(desc(chatsTable.lastMessageAt));

  if (chats.length === 0) {
    res.json({ chats: [] });
    return;
  }

  const otherIds = Array.from(
    new Set(chats.map((c) => (c.userAId === me ? c.userBId : c.userAId))),
  );
  const productIds = Array.from(
    new Set(chats.map((c) => c.productId).filter((x): x is string => !!x)),
  );

  const [others, prods] = await Promise.all([
    otherIds.length
      ? db.select().from(usersTable).where(inArray(usersTable.id, otherIds))
      : Promise.resolve([] as UserRow[]),
    productIds.length
      ? db
          .select()
          .from(productsTable)
          .where(inArray(productsTable.id, productIds))
      : Promise.resolve([] as ProductRow[]),
  ]);
  const otherMap = new Map(others.map((u) => [u.id, u]));
  const prodMap = new Map(prods.map((p) => [p.id, p]));

  const chatIds = chats.map((c) => c.id);
  const lastMsgs = await db.execute<{
    id: string;
    chat_id: string;
    sender_id: string;
    body: string;
    read_at: Date | null;
    created_at: Date;
  }>(sql`
    SELECT DISTINCT ON (chat_id) id, chat_id, sender_id, body, read_at, created_at
    FROM messages
    WHERE chat_id = ANY(${chatIds}::uuid[])
    ORDER BY chat_id, created_at DESC
  `);
  const lastMap = new Map<string, MessageRow>();
  for (const r of lastMsgs.rows) {
    lastMap.set(r.chat_id, {
      id: r.id,
      chatId: r.chat_id,
      senderId: r.sender_id,
      body: r.body,
      readAt: r.read_at,
      createdAt: r.created_at,
    });
  }

  const unreadRows = await db
    .select({
      chatId: messagesTable.chatId,
      count: sql<number>`count(*)::int`,
    })
    .from(messagesTable)
    .where(
      and(
        inArray(messagesTable.chatId, chatIds),
        sql`${messagesTable.senderId} <> ${me}`,
        isNull(messagesTable.readAt),
      ),
    )
    .groupBy(messagesTable.chatId);
  const unreadMap = new Map(unreadRows.map((u) => [u.chatId, u.count]));

  res.json({
    chats: chats.map((c) => {
      const otherId = c.userAId === me ? c.userBId : c.userAId;
      const other = otherMap.get(otherId);
      const last = lastMap.get(c.id);
      const product = c.productId ? prodMap.get(c.productId) : undefined;
      return {
        id: c.id,
        otherUser: other
          ? serializePeer(other)
          : {
              id: otherId,
              name: "Unknown",
              username: "unknown",
              profilePicUrl: null,
              premiumTier: "free" as const,
              isVerified: false,
            },
        product: product ? serializeProduct(product) : null,
        lastMessage: last ? serializeMessage(last) : null,
        unreadCount: unreadMap.get(c.id) ?? 0,
        updatedAt: c.lastMessageAt.toISOString(),
        createdAt: c.createdAt.toISOString(),
      };
    }),
  });
});

router.get("/chats/unread", requireAuth, async (req, res): Promise<void> => {
  const me = req.user!.id;
  const rows = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(messagesTable)
    .innerJoin(chatsTable, eq(chatsTable.id, messagesTable.chatId))
    .where(
      and(
        or(eq(chatsTable.userAId, me), eq(chatsTable.userBId, me)),
        sql`${messagesTable.senderId} <> ${me}`,
        isNull(messagesTable.readAt),
      ),
    );
  res.json({ unread: rows[0]?.count ?? 0 });
});

router.post("/chats", requireAuth, async (req, res): Promise<void> => {
  const parsed = OpenChatBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const me = req.user!.id;
  const { otherUserId, productId } = parsed.data;
  if (otherUserId === me) {
    res.status(400).json({ error: "Cannot chat with yourself" });
    return;
  }
  const [other] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, otherUserId))
    .limit(1);
  if (!other) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const [a, b] = orderPair(me, otherUserId);
  const productCondition = productId
    ? eq(chatsTable.productId, productId)
    : isNull(chatsTable.productId);

  let chat: ChatRow | undefined;
  const existing = await db
    .select()
    .from(chatsTable)
    .where(
      and(
        eq(chatsTable.userAId, a),
        eq(chatsTable.userBId, b),
        productCondition,
      ),
    )
    .limit(1);
  chat = existing[0];

  if (!chat) {
    const [created] = await db
      .insert(chatsTable)
      .values({ userAId: a, userBId: b, productId: productId ?? null })
      .returning();
    chat = created;
  }

  let product: ProductRow | undefined;
  if (chat.productId) {
    const [p] = await db
      .select()
      .from(productsTable)
      .where(eq(productsTable.id, chat.productId))
      .limit(1);
    product = p;
  }

  res.json({
    id: chat.id,
    otherUser: serializePeer(other),
    product: product ? serializeProduct(product) : null,
    lastMessage: null,
    unreadCount: 0,
    updatedAt: chat.lastMessageAt.toISOString(),
    createdAt: chat.createdAt.toISOString(),
  });
});

async function loadChatForUser(
  chatId: string,
  userId: string,
): Promise<ChatRow | null> {
  const rows = await db
    .select()
    .from(chatsTable)
    .where(
      and(
        eq(chatsTable.id, chatId),
        or(eq(chatsTable.userAId, userId), eq(chatsTable.userBId, userId)),
      ),
    )
    .limit(1);
  return rows[0] ?? null;
}

router.get(
  "/chats/:chatId/messages",
  requireAuth,
  async (req, res): Promise<void> => {
    const params = ListMessagesParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const me = req.user!.id;
    const chat = await loadChatForUser(params.data.chatId, me);
    if (!chat) {
      res.status(404).json({ error: "Chat not found" });
      return;
    }
    const messages = await db
      .select()
      .from(messagesTable)
      .where(eq(messagesTable.chatId, chat.id))
      .orderBy(asc(messagesTable.createdAt))
      .limit(500);

    await db
      .update(messagesTable)
      .set({ readAt: new Date() })
      .where(
        and(
          eq(messagesTable.chatId, chat.id),
          sql`${messagesTable.senderId} <> ${me}`,
          isNull(messagesTable.readAt),
        ),
      );

    res.json({ messages: messages.map(serializeMessage) });
  },
);

router.post(
  "/chats/:chatId/messages",
  requireAuth,
  async (req, res): Promise<void> => {
    const params = SendMessageParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const body = SendMessageBody.safeParse(req.body);
    if (!body.success) {
      res.status(400).json({ error: body.error.message });
      return;
    }
    const me = req.user!.id;
    const chat = await loadChatForUser(params.data.chatId, me);
    if (!chat) {
      res.status(404).json({ error: "Chat not found" });
      return;
    }
    const text = body.data.body.trim();
    if (text.length === 0) {
      res.status(400).json({ error: "Empty message" });
      return;
    }
    const [msg] = await db
      .insert(messagesTable)
      .values({ chatId: chat.id, senderId: me, body: text })
      .returning();
    await db
      .update(chatsTable)
      .set({ lastMessageAt: new Date() })
      .where(eq(chatsTable.id, chat.id));
    res.json(serializeMessage(msg));
  },
);

export default router;
