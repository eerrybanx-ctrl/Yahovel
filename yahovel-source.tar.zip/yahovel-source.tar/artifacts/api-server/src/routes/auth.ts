import { Router, type IRouter } from "express";
import { eq, or } from "drizzle-orm";
import { db, usersTable } from "@workspace/db";
import {
  CheckAvailabilityBody,
  SignupBody,
  LoginBody,
} from "@workspace/api-zod";
import {
  hashPassword,
  verifyPassword,
  createSession,
  destroySession,
  setSessionCookie,
  clearSessionCookie,
  getSessionId,
} from "../lib/auth";
import { serializeUser } from "../lib/serialize";

const router: IRouter = Router();

router.post("/auth/check", async (req, res): Promise<void> => {
  const parsed = CheckAvailabilityBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { email, phone, username } = parsed.data;
  const result = {
    emailAvailable: true,
    phoneAvailable: true,
    usernameAvailable: true,
  };
  if (email) {
    const r = await db
      .select({ id: usersTable.id })
      .from(usersTable)
      .where(eq(usersTable.email, email.toLowerCase()))
      .limit(1);
    result.emailAvailable = r.length === 0;
  }
  if (phone) {
    const r = await db
      .select({ id: usersTable.id })
      .from(usersTable)
      .where(eq(usersTable.phone, phone))
      .limit(1);
    result.phoneAvailable = r.length === 0;
  }
  if (username) {
    const r = await db
      .select({ id: usersTable.id })
      .from(usersTable)
      .where(eq(usersTable.username, username.toLowerCase()))
      .limit(1);
    result.usernameAvailable = r.length === 0;
  }
  res.json(result);
});

router.post("/auth/signup", async (req, res): Promise<void> => {
  const parsed = SignupBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { name, username, email, phone, password, city } = parsed.data;
  const emailLc = email.toLowerCase();
  const usernameLc = username.toLowerCase();

  const existing = await db
    .select()
    .from(usersTable)
    .where(
      or(
        eq(usersTable.email, emailLc),
        eq(usersTable.phone, phone),
        eq(usersTable.username, usernameLc),
      ),
    );

  for (const e of existing) {
    if (e.email === emailLc) {
      res
        .status(409)
        .json({ error: "Email already in use", field: "email" });
      return;
    }
    if (e.phone === phone) {
      res
        .status(409)
        .json({ error: "Phone already in use", field: "phone" });
      return;
    }
    if (e.username === usernameLc) {
      res
        .status(409)
        .json({ error: "Username already taken", field: "username" });
      return;
    }
  }

  const passwordHash = await hashPassword(password);
  const [user] = await db
    .insert(usersTable)
    .values({
      name,
      username: usernameLc,
      email: emailLc,
      phone,
      passwordHash,
      city: city ?? null,
    })
    .returning();

  const sid = await createSession(user.id);
  setSessionCookie(res, sid);
  res.json({ user: serializeUser(user) });
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { identifier, password } = parsed.data;
  const id = identifier.trim();
  const lc = id.toLowerCase();

  const rows = await db
    .select()
    .from(usersTable)
    .where(
      or(
        eq(usersTable.email, lc),
        eq(usersTable.username, lc),
        eq(usersTable.phone, id),
      ),
    )
    .limit(1);
  const user = rows[0];
  if (!user) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }
  const ok = await verifyPassword(password, user.passwordHash);
  if (!ok) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }
  const sid = await createSession(user.id);
  setSessionCookie(res, sid);
  res.json({ user: serializeUser(user) });
});

router.post("/auth/logout", async (req, res): Promise<void> => {
  const sid = getSessionId(req);
  if (sid) await destroySession(sid);
  clearSessionCookie(res);
  res.json({ ok: true });
});

router.get("/auth/me", async (req, res): Promise<void> => {
  res.json({ user: req.user ? serializeUser(req.user) : null });
});

export default router;
