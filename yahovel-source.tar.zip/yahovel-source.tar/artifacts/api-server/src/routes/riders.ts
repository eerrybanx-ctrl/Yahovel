import { Router, type IRouter } from "express";
import { eq, and, gt } from "drizzle-orm";
import { db, usersTable } from "@workspace/db";
import {
  UpdateRiderBody,
  ListOnlineRidersQueryParams,
} from "@workspace/api-zod";
import { requireAuth } from "../lib/auth";
import { serializeUser, distanceKm } from "../lib/serialize";

const router: IRouter = Router();

router.patch(
  "/riders/me",
  requireAuth,
  async (req, res): Promise<void> => {
    const parsed = UpdateRiderBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }
    const data = parsed.data;
    const update: Record<string, unknown> = {};
    if (data.isRider !== undefined) update.isRider = data.isRider;
    if (data.vehicle !== undefined) update.riderVehicle = data.vehicle;
    if (data.online !== undefined) {
      update.riderOnline = data.online;
      if (data.online === false) {
        update.riderLastSeenAt = new Date();
      }
    }
    if (data.lat !== undefined) update.riderLat = data.lat;
    if (data.lng !== undefined) update.riderLng = data.lng;
    if (data.online === true || data.lat !== undefined) {
      update.riderLastSeenAt = new Date();
    }
    const [updated] = await db
      .update(usersTable)
      .set(update)
      .where(eq(usersTable.id, req.user!.id))
      .returning();
    res.json(serializeUser(updated));
  },
);

router.get("/riders/online", async (req, res): Promise<void> => {
  const parsed = ListOnlineRidersQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { lat, lng } = parsed.data;
  const stale = new Date(Date.now() - 5 * 60 * 1000);
  const rows = await db
    .select()
    .from(usersTable)
    .where(
      and(
        eq(usersTable.riderOnline, true),
        eq(usersTable.isRider, true),
        gt(usersTable.riderLastSeenAt, stale),
      ),
    );
  const riders = rows
    .filter((u) => u.riderLat != null && u.riderLng != null)
    .map((u) => {
      const dist =
        lat != null && lng != null && u.riderLat != null && u.riderLng != null
          ? distanceKm(lat, lng, u.riderLat, u.riderLng)
          : null;
      const vehicle =
        u.riderVehicle === "moto" ||
        u.riderVehicle === "car" ||
        u.riderVehicle === "bicycle" ||
        u.riderVehicle === "truck"
          ? u.riderVehicle
          : "moto";
      return {
        id: u.id,
        name: u.name,
        username: u.username,
        phone: u.phone,
        profilePicUrl: u.profilePicUrl,
        vehicle,
        lat: u.riderLat!,
        lng: u.riderLng!,
        rating: u.rating,
        distanceKm: dist,
        lastSeenAt: (u.riderLastSeenAt ?? new Date()).toISOString(),
      };
    });
  res.json({ riders });
});

export default router;
