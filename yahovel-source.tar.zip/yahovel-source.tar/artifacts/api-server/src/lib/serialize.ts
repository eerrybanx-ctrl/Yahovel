import type { UserRow, ProductRow } from "@workspace/db";

const VEHICLES = new Set(["moto", "car", "bicycle", "truck"]);
const TIERS = new Set(["free", "basic", "silver", "gold", "diamond"]);

export interface PublicUser {
  id: string;
  name: string;
  username: string;
  email: string;
  phone: string;
  bio: string | null;
  profilePicUrl: string | null;
  city: string | null;
  lat: number | null;
  lng: number | null;
  isVerified: boolean;
  premiumTier: "free" | "basic" | "silver" | "gold" | "diamond";
  premiumExpiresAt: string | null;
  isRider: boolean;
  riderVehicle: "moto" | "car" | "bicycle" | "truck" | null;
  riderOnline: boolean;
  riderLat: number | null;
  riderLng: number | null;
  themePreference: "dark" | "light";
  rating: number;
  reviewCount: number;
  createdAt: string;
}

function tier(value: string): PublicUser["premiumTier"] {
  return TIERS.has(value)
    ? (value as PublicUser["premiumTier"])
    : "free";
}

function vehicle(value: string | null): PublicUser["riderVehicle"] {
  if (value && VEHICLES.has(value))
    return value as PublicUser["riderVehicle"];
  return null;
}

export function serializeUser(u: UserRow): PublicUser {
  return {
    id: u.id,
    name: u.name,
    username: u.username,
    email: u.email,
    phone: u.phone,
    bio: u.bio,
    profilePicUrl: u.profilePicUrl,
    city: u.city,
    lat: u.lat,
    lng: u.lng,
    isVerified: u.isVerified,
    premiumTier: tier(u.premiumTier),
    premiumExpiresAt: u.premiumExpiresAt
      ? u.premiumExpiresAt.toISOString()
      : null,
    isRider: u.isRider,
    riderVehicle: vehicle(u.riderVehicle),
    riderOnline: u.riderOnline,
    riderLat: u.riderLat,
    riderLng: u.riderLng,
    themePreference: u.themePreference === "light" ? "light" : "dark",
    rating: u.rating,
    reviewCount: u.reviewCount,
    createdAt: u.createdAt.toISOString(),
  };
}

export interface SellerSummary {
  sellerId: string;
  sellerName: string;
  sellerUsername: string;
  sellerPremiumTier: PublicUser["premiumTier"];
  sellerVerified: boolean;
  sellerRating: number;
}

export interface PublicProduct extends SellerSummary {
  id: string;
  title: string;
  description: string;
  price: number;
  currency: string;
  category: string;
  condition: string;
  images: string[];
  city: string | null;
  lat: number | null;
  lng: number | null;
  isBoosted: boolean;
  boostedUntil: string | null;
  distanceKm: number | null;
  viewCount: number;
  createdAt: string;
}

export function serializeProduct(
  p: ProductRow,
  seller: UserRow,
  distanceKm: number | null = null,
): PublicProduct {
  const isBoostedActive =
    p.isBoosted && p.boostedUntil != null && p.boostedUntil.getTime() > Date.now();
  return {
    id: p.id,
    sellerId: seller.id,
    sellerName: seller.name,
    sellerUsername: seller.username,
    sellerPremiumTier: tier(seller.premiumTier),
    sellerVerified: seller.isVerified,
    sellerRating: seller.rating,
    title: p.title,
    description: p.description,
    price: p.price,
    currency: p.currency,
    category: p.category,
    condition: p.condition,
    images: p.images ?? [],
    city: p.city,
    lat: p.lat,
    lng: p.lng,
    isBoosted: isBoostedActive,
    boostedUntil: p.boostedUntil ? p.boostedUntil.toISOString() : null,
    distanceKm,
    viewCount: p.viewCount,
    createdAt: p.createdAt.toISOString(),
  };
}

export function distanceKm(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number,
): number {
  const R = 6371;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLng / 2) ** 2;
  return Math.round(2 * R * Math.asin(Math.sqrt(a)) * 10) / 10;
}

const TIER_RANK: Record<PublicUser["premiumTier"], number> = {
  free: 0,
  basic: 1,
  silver: 2,
  gold: 3,
  diamond: 4,
};

export function tierRank(t: PublicUser["premiumTier"]): number {
  return TIER_RANK[t];
}
