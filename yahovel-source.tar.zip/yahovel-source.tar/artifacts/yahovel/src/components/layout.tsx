import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Home, Map as MapIcon, PlusCircle, Grid, User, LogIn, Crown, Moon, Sun, MessageSquare } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { useUpdateMe, useGetUnreadCount, getGetUnreadCountQueryKey } from "@workspace/api-client-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export function Header() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const updateMe = useUpdateMe();
  const { data: unread } = useGetUnreadCount({
    query: {
      enabled: !!user,
      refetchInterval: 10000,
      queryKey: getGetUnreadCountQueryKey(),
    },
  });
  const unreadCount = unread?.unread ?? 0;

  const toggleTheme = () => {
    const isDark = document.documentElement.classList.contains("dark");
    const newTheme = isDark ? "light" : "dark";

    if (user) {
      updateMe.mutate({ data: { themePreference: newTheme } });
    } else {
      localStorage.setItem("theme", newTheme);
    }
    
    if (newTheme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto max-w-md flex h-14 items-center justify-between px-4">
        <Link href="/" className="font-black text-xl tracking-tighter text-primary">
          YAHOVEL
        </Link>

        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={toggleTheme} className="h-8 w-8 text-muted-foreground hover:text-foreground">
            <span className="sr-only">Toggle theme</span>
            <Sun className="h-4 w-4 hidden dark:block" />
            <Moon className="h-4 w-4 block dark:hidden" />
          </Button>

          <Link href="/premium">
            <Button variant="ghost" size="icon" className="h-8 w-8 text-amber-500 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-950/30">
              <Crown className="h-4 w-4" />
            </Button>
          </Link>

          {user && (
            <Link href="/messages">
              <Button variant="ghost" size="icon" className="h-8 w-8 relative text-muted-foreground hover:text-foreground">
                <MessageSquare className="h-4 w-4" />
                {unreadCount > 0 && (
                  <Badge className="absolute -top-1 -right-1 h-4 min-w-4 px-1 rounded-full bg-primary text-primary-foreground text-[9px] font-bold border-0 flex items-center justify-center">
                    {unreadCount > 9 ? "9+" : unreadCount}
                  </Badge>
                )}
              </Button>
            </Link>
          )}

          {user ? (
            <Link href="/profile">
              <Avatar className="h-8 w-8 border border-border cursor-pointer">
                <AvatarImage src={user.profilePicUrl || ""} />
                <AvatarFallback>{user.name?.charAt(0) || "U"}</AvatarFallback>
              </Avatar>
            </Link>
          ) : (
            <Link href="/auth">
              <Button size="sm" variant="default" className="h-8 text-xs font-semibold rounded-full px-4">
                Sign In
              </Button>
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}

export function BottomNav() {
  const [location] = useLocation();

  const navItems = [
    { icon: Home, label: "Home", href: "/" },
    { icon: MapIcon, label: "Riders", href: "/riders" },
    { icon: PlusCircle, label: "Post", href: "/post", accent: true },
    { icon: Grid, label: "My Items", href: "/mine" },
    { icon: User, label: "Profile", href: "/profile" },
  ];

  return (
    <nav className="fixed bottom-0 z-50 w-full border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 pb-safe">
      <div className="container mx-auto max-w-md flex items-center justify-around h-16 px-2">
        {navItems.map((item) => {
          const isActive = location === item.href;
          const Icon = item.icon;
          
          if (item.accent) {
            return (
              <Link key={item.href} href={item.href} className="flex flex-col items-center justify-center w-14 -mt-6">
                <div className="h-12 w-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-lg shadow-primary/20 active:scale-95 transition-transform">
                  <Icon className="h-6 w-6" strokeWidth={2.5} />
                </div>
                <span className="text-[10px] mt-1 font-medium text-primary">Post</span>
              </Link>
            );
          }

          return (
            <Link key={item.href} href={item.href} className="flex flex-col items-center justify-center w-14 h-full gap-1 group">
              <Icon 
                className={`h-5 w-5 transition-colors ${isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground"}`} 
                strokeWidth={isActive ? 2.5 : 2}
              />
              <span className={`text-[10px] font-medium transition-colors ${isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground"}`}>
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}