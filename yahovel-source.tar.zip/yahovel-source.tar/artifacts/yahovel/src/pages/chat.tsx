import { useEffect, useRef, useState } from "react";
import { useRoute, useLocation, Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListMessages,
  useListChats,
  useSendMessage,
  getListMessagesQueryKey,
  getListChatsQueryKey,
  getGetUnreadCountQueryKey,
} from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth-context";
import { Header } from "@/components/layout";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Send, ShieldCheck } from "lucide-react";

function formatTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}

export default function ChatPage() {
  const [, params] = useRoute("/messages/:chatId");
  const chatId = params?.chatId || "";
  const [, setLocation] = useLocation();
  const { user, isLoading: authLoading } = useAuth();
  const queryClient = useQueryClient();
  const [draft, setDraft] = useState("");
  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!authLoading && !user) setLocation("/auth");
  }, [authLoading, user, setLocation]);

  const { data: chatList } = useListChats({
    query: { enabled: !!user, queryKey: getListChatsQueryKey() },
  });
  const chat = chatList?.chats.find((c) => c.id === chatId);

  const { data: messagesData, isLoading } = useListMessages(chatId, {
    query: {
      enabled: !!chatId && !!user,
      refetchInterval: 3000,
      queryKey: getListMessagesQueryKey(chatId),
    },
  });

  const sendMessage = useSendMessage({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({
          queryKey: getListMessagesQueryKey(chatId),
        });
        queryClient.invalidateQueries({ queryKey: getListChatsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetUnreadCountQueryKey() });
      },
    },
  });

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messagesData?.messages.length]);

  useEffect(() => {
    queryClient.invalidateQueries({ queryKey: getGetUnreadCountQueryKey() });
  }, [messagesData, queryClient]);

  const onSend = (e: React.FormEvent) => {
    e.preventDefault();
    const body = draft.trim();
    if (!body || sendMessage.isPending) return;
    sendMessage.mutate(
      { chatId, data: { body } },
      {
        onSuccess: () => setDraft(""),
      },
    );
  };

  return (
    <div className="min-h-[100dvh] flex flex-col bg-muted/20">
      <Header />

      <div className="sticky top-14 z-40 bg-background border-b">
        <div className="container mx-auto max-w-md flex items-center gap-3 px-4 h-14">
          <Link href="/messages">
            <Button variant="ghost" size="icon" className="h-8 w-8 -ml-2">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          {chat ? (
            <Link href={`/seller/${chat.otherUser.id}`} className="flex items-center gap-2 flex-1 min-w-0">
              <Avatar className="h-8 w-8 border">
                <AvatarImage src={chat.otherUser.profilePicUrl || ""} />
                <AvatarFallback className="bg-primary/10 text-primary text-xs font-bold">
                  {chat.otherUser.name.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1">
                  <span className="font-semibold text-sm truncate">
                    {chat.otherUser.name}
                  </span>
                  {chat.otherUser.isVerified && (
                    <ShieldCheck className="h-3.5 w-3.5 text-blue-500 shrink-0" />
                  )}
                </div>
                {chat.product && (
                  <span className="text-[11px] text-primary truncate block">
                    Re: {chat.product.title}
                  </span>
                )}
              </div>
              {chat.otherUser.premiumTier !== "free" && (
                <Badge
                  variant="outline"
                  className="text-[10px] capitalize border-primary/30 text-primary"
                >
                  {chat.otherUser.premiumTier}
                </Badge>
              )}
            </Link>
          ) : (
            <div className="flex-1">
              <Skeleton className="h-4 w-32" />
            </div>
          )}
        </div>
        {chat?.product && (
          <Link href={`/product/${chat.product.id}`}>
            <div className="container mx-auto max-w-md px-4 pb-3">
              <div className="flex items-center gap-3 bg-muted/40 rounded-lg p-2 border cursor-pointer hover:border-primary/40 transition-colors">
                {chat.product.image ? (
                  <img
                    src={chat.product.image}
                    alt={chat.product.title}
                    className="h-10 w-10 rounded object-cover"
                  />
                ) : (
                  <div className="h-10 w-10 rounded bg-muted" />
                )}
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium truncate">
                    {chat.product.title}
                  </p>
                  <p className="text-xs font-bold text-primary">
                    {chat.product.currency} {chat.product.price.toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
          </Link>
        )}
      </div>

      <main
        ref={scrollRef}
        className="flex-1 overflow-y-auto container mx-auto max-w-md px-4 py-4 space-y-2"
      >
        {isLoading ? (
          <div className="space-y-3">
            {[0, 1, 2].map((i) => (
              <Skeleton key={i} className={`h-10 ${i % 2 === 0 ? "w-2/3" : "w-1/2 ml-auto"}`} />
            ))}
          </div>
        ) : !messagesData || messagesData.messages.length === 0 ? (
          <div className="text-center text-muted-foreground text-sm py-12">
            No messages yet. Say hello!
          </div>
        ) : (
          messagesData.messages.map((m) => {
            const mine = m.senderId === user?.id;
            return (
              <div
                key={m.id}
                className={`flex ${mine ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[75%] rounded-2xl px-3.5 py-2 text-sm shadow-xs ${
                    mine
                      ? "bg-primary text-primary-foreground rounded-br-sm"
                      : "bg-card border rounded-bl-sm"
                  }`}
                >
                  <p className="whitespace-pre-wrap break-words leading-snug">
                    {m.body}
                  </p>
                  <p
                    className={`text-[10px] mt-1 ${mine ? "text-primary-foreground/70" : "text-muted-foreground"} text-right`}
                  >
                    {formatTime(m.createdAt)}
                  </p>
                </div>
              </div>
            );
          })
        )}
      </main>

      <form
        onSubmit={onSend}
        className="sticky bottom-0 bg-background border-t"
      >
        <div className="container mx-auto max-w-md px-4 py-3 flex gap-2 pb-safe">
          <Input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="Type a message..."
            maxLength={2000}
            className="rounded-full bg-muted/50 border-muted"
            autoComplete="off"
          />
          <Button
            type="submit"
            size="icon"
            disabled={!draft.trim() || sendMessage.isPending}
            className="rounded-full h-10 w-10 shrink-0"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </form>
    </div>
  );
}
