import { useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useLogin, useSignup, useCheckAvailability } from "@workspace/api-client-react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Loader2, CheckCircle2, XCircle } from "lucide-react";

export default function AuthPage() {
  const [location, setLocation] = useLocation();
  const { user, refetch } = useAuth();
  const { toast } = useToast();
  
  if (user) {
    setLocation("/");
    return null;
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-muted/30">
      <div className="w-full max-w-md bg-card border rounded-xl shadow-sm p-6">
        <div className="text-center mb-6">
          <h1 className="text-2xl font-black text-primary tracking-tight">YAHOVEL</h1>
          <p className="text-sm text-muted-foreground mt-1">Join the neighborhood market</p>
        </div>
        
        <Tabs defaultValue="login" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="login">Sign In</TabsTrigger>
            <TabsTrigger value="signup">Create Account</TabsTrigger>
          </TabsList>
          
          <TabsContent value="login">
            <LoginForm onSuccess={() => {
              refetch();
              setLocation("/");
            }} />
          </TabsContent>
          
          <TabsContent value="signup">
            <SignupForm onSuccess={() => {
              refetch();
              setLocation("/");
            }} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function LoginForm({ onSuccess }: { onSuccess: () => void }) {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const login = useLogin();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    login.mutate({ data: { identifier, password } }, {
      onSuccess: () => {
        toast({ title: "Welcome back!" });
        onSuccess();
      },
      onError: (err: any) => {
        toast({ 
          title: "Login failed", 
          description: err.message || "Invalid credentials",
          variant: "destructive"
        });
      }
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="identifier">Email, Phone, or Username</Label>
        <Input 
          id="identifier" 
          value={identifier} 
          onChange={e => setIdentifier(e.target.value)} 
          required 
          disabled={login.isPending}
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="password">Password</Label>
        <Input 
          id="password" 
          type="password" 
          value={password} 
          onChange={e => setPassword(e.target.value)} 
          required 
          disabled={login.isPending}
        />
      </div>
      <Button type="submit" className="w-full font-semibold" disabled={login.isPending}>
        {login.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
        Sign In
      </Button>
    </form>
  );
}

function SignupForm({ onSuccess }: { onSuccess: () => void }) {
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [city, setCity] = useState("");
  
  const signup = useSignup();
  const check = useCheckAvailability();
  const { toast } = useToast();

  const [usernameStatus, setUsernameStatus] = useState<"idle" | "checking" | "available" | "taken">("idle");
  const [emailStatus, setEmailStatus] = useState<"idle" | "checking" | "available" | "taken">("idle");
  const [phoneStatus, setPhoneStatus] = useState<"idle" | "checking" | "available" | "taken">("idle");

  // A real app would debounce these checks
  const checkField = (field: "username" | "email" | "phone", value: string) => {
    if (!value || value.length < 3) {
      if (field === 'username') setUsernameStatus("idle");
      if (field === 'email') setEmailStatus("idle");
      if (field === 'phone') setPhoneStatus("idle");
      return;
    }

    if (field === 'username') setUsernameStatus("checking");
    if (field === 'email') setEmailStatus("checking");
    if (field === 'phone') setPhoneStatus("checking");

    check.mutate({ data: { [field]: value } }, {
      onSuccess: (res) => {
        if (field === 'username') setUsernameStatus(res.usernameAvailable ? "available" : "taken");
        if (field === 'email') setEmailStatus(res.emailAvailable ? "available" : "taken");
        if (field === 'phone') setPhoneStatus(res.phoneAvailable ? "available" : "taken");
      }
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (usernameStatus === "taken" || emailStatus === "taken" || phoneStatus === "taken") {
      toast({ title: "Please fix validation errors", variant: "destructive" });
      return;
    }
    
    if (password.length < 8) {
      toast({ title: "Password must be at least 8 characters", variant: "destructive" });
      return;
    }

    signup.mutate({ data: { name, username, email, phone, password, city } }, {
      onSuccess: () => {
        toast({ title: "Account created successfully!" });
        onSuccess();
      },
      onError: (err: any) => {
        toast({ 
          title: "Signup failed", 
          description: err.message || "An error occurred",
          variant: "destructive"
        });
      }
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Full Name</Label>
        <Input id="name" value={name} onChange={e => setName(e.target.value)} required disabled={signup.isPending} />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="username">Username</Label>
        <div className="relative">
          <Input 
            id="username" 
            value={username} 
            onChange={e => {
              setUsername(e.target.value);
              // Simplified for speed without a real debounce hook
              setTimeout(() => checkField("username", e.target.value), 400);
            }} 
            required 
            disabled={signup.isPending} 
          />
          <div className="absolute right-3 top-2.5">
            {usernameStatus === "checking" && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />}
            {usernameStatus === "available" && <CheckCircle2 className="h-4 w-4 text-green-500" />}
            {usernameStatus === "taken" && <XCircle className="h-4 w-4 text-destructive" />}
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="email">Email</Label>
        <div className="relative">
          <Input 
            id="email" 
            type="email"
            value={email} 
            onChange={e => {
              setEmail(e.target.value);
              setTimeout(() => checkField("email", e.target.value), 400);
            }} 
            required 
            disabled={signup.isPending} 
          />
          <div className="absolute right-3 top-2.5">
            {emailStatus === "checking" && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />}
            {emailStatus === "available" && <CheckCircle2 className="h-4 w-4 text-green-500" />}
            {emailStatus === "taken" && <XCircle className="h-4 w-4 text-destructive" />}
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="phone">Phone Number</Label>
        <div className="relative">
          <Input 
            id="phone" 
            type="tel"
            value={phone} 
            onChange={e => {
              setPhone(e.target.value);
              setTimeout(() => checkField("phone", e.target.value), 400);
            }} 
            required 
            disabled={signup.isPending} 
          />
          <div className="absolute right-3 top-2.5">
            {phoneStatus === "checking" && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />}
            {phoneStatus === "available" && <CheckCircle2 className="h-4 w-4 text-green-500" />}
            {phoneStatus === "taken" && <XCircle className="h-4 w-4 text-destructive" />}
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="city">City (Optional)</Label>
        <Input id="city" value={city} onChange={e => setCity(e.target.value)} disabled={signup.isPending} />
      </div>

      <div className="space-y-2">
        <Label htmlFor="new-password">Password</Label>
        <Input 
          id="new-password" 
          type="password" 
          value={password} 
          onChange={e => setPassword(e.target.value)} 
          required 
          disabled={signup.isPending}
          minLength={8}
        />
        <p className="text-[10px] text-muted-foreground">Minimum 8 characters</p>
      </div>

      <Button type="submit" className="w-full font-semibold" disabled={signup.isPending}>
        {signup.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
        Create Account
      </Button>
    </form>
  );
}
