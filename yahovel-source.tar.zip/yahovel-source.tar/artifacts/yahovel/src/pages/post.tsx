import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/lib/auth-context";
import { useCreateProduct, getListProductsQueryKey, getListMyProductsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Header, BottomNav } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Loader2, MapPin, ImagePlus } from "lucide-react";

const CATEGORIES = [
  "Electronics", "Fashion", "Vehicles", "Real Estate", 
  "Food", "Services", "Beauty", "Home", "Jobs"
];

const CONDITIONS = ["New", "Like New", "Good", "Fair", "Used"];

export default function PostPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const createProduct = useCreateProduct();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [category, setCategory] = useState("");
  const [condition, setCondition] = useState("");
  const [images, setImages] = useState("");
  const [city, setCity] = useState("");
  const [coords, setCoords] = useState<{lat: number, lng: number} | null>(null);
  const [gettingLoc, setGettingLoc] = useState(false);

  if (!user) {
    setLocation("/auth");
    return null;
  }

  const handleGetLocation = () => {
    setGettingLoc(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setGettingLoc(false);
        toast({ title: "Location pinned" });
      },
      (err) => {
        setGettingLoc(false);
        toast({ title: "Could not get location", variant: "destructive" });
      }
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!category) {
      toast({ title: "Please select a category", variant: "destructive" });
      return;
    }

    const imageArray = images.split(",").map(s => s.trim()).filter(Boolean);

    createProduct.mutate({
      data: {
        title,
        description,
        price: Number(price),
        category,
        condition: condition || undefined,
        images: imageArray,
        city: city || undefined,
        lat: coords?.lat,
        lng: coords?.lng,
      }
    }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListMyProductsQueryKey() });
        toast({ title: "Product posted successfully!" });
        setLocation("/mine");
      },
      onError: (err: any) => {
        toast({ title: "Failed to post", description: err.message, variant: "destructive" });
      }
    });
  };

  return (
    <div className="min-h-[100dvh] flex flex-col bg-muted/20 pb-20">
      <Header />
      
      <main className="flex-1 container mx-auto max-w-md p-4">
        <h1 className="text-2xl font-black mb-6">Post an Item</h1>
        
        <form onSubmit={handleSubmit} className="space-y-4 bg-card p-4 rounded-xl border shadow-sm">
          <div className="space-y-2">
            <Label>Title</Label>
            <Input value={title} onChange={e => setTitle(e.target.value)} required placeholder="What are you selling?" />
          </div>

          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea value={description} onChange={e => setDescription(e.target.value)} required placeholder="Describe your item..." className="min-h-[100px]" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Price (GHS)</Label>
              <Input type="number" min="0" value={price} onChange={e => setPrice(e.target.value)} required placeholder="0.00" />
            </div>
            <div className="space-y-2">
              <Label>Category</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="Select..." />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Condition</Label>
            <Select value={condition} onValueChange={setCondition}>
              <SelectTrigger>
                <SelectValue placeholder="Optional" />
              </SelectTrigger>
              <SelectContent>
                {CONDITIONS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Images (Comma-separated URLs)</Label>
            <div className="relative">
              <ImagePlus className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input value={images} onChange={e => setImages(e.target.value)} placeholder="https://..., https://..." className="pl-9" />
            </div>
            <p className="text-[10px] text-muted-foreground">We'll support direct uploads soon.</p>
          </div>

          <div className="space-y-2 pt-2 border-t">
            <Label>Location (Optional)</Label>
            <Input value={city} onChange={e => setCity(e.target.value)} placeholder="City or neighborhood" className="mb-2" />
            <Button type="button" variant="outline" size="sm" className="w-full text-xs" onClick={handleGetLocation} disabled={gettingLoc}>
              {gettingLoc ? <Loader2 className="h-3 w-3 animate-spin mr-2" /> : <MapPin className="h-3 w-3 mr-2" />}
              {coords ? "Location Pinned ✓" : "Use My Current Location"}
            </Button>
          </div>

          <Button type="submit" className="w-full mt-6 font-bold" disabled={createProduct.isPending}>
            {createProduct.isPending && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
            Post Item
          </Button>
        </form>
      </main>

      <BottomNav />
    </div>
  );
}