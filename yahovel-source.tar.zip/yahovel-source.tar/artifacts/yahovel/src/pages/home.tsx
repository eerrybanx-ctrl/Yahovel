import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useListProducts } from "@workspace/api-client-react";
import { Header, BottomNav } from "@/components/layout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, MapPin, Zap, Star, ShieldCheck, MapIcon, Car, Bike, ShoppingBag, Smartphone, Home as HomeIcon, Scissors, Briefcase, Heart, Coffee } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const CATEGORIES = [
  { id: "Electronics", icon: Smartphone },
  { id: "Fashion", icon: ShoppingBag },
  { id: "Vehicles", icon: Car },
  { id: "Real Estate", icon: HomeIcon },
  { id: "Food", icon: Coffee },
  { id: "Services", icon: Briefcase },
  { id: "Beauty", icon: Scissors },
  { id: "Home", icon: Heart },
  { id: "Jobs", icon: Briefcase },
];

export default function HomePage() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<string | undefined>();
  const [nearby, setNearby] = useState(false);
  const [coords, setCoords] = useState<{lat: number, lng: number} | null>(null);
  const { toast } = useToast();

  const handleNearbyToggle = () => {
    if (!nearby) {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            setCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude });
            setNearby(true);
            toast({ title: "Location accessed", description: "Showing nearby listings first" });
          },
          (err) => {
            toast({ title: "Location failed", description: err.message, variant: "destructive" });
          }
        );
      } else {
        toast({ title: "Not supported", description: "Geolocation is not supported by your browser", variant: "destructive" });
      }
    } else {
      setNearby(false);
      setCoords(null);
    }
  };

  const { data: listData, isLoading } = useListProducts({
    search: search || undefined,
    category: category || undefined,
    lat: coords?.lat,
    lng: coords?.lng,
    radiusKm: nearby ? 20 : undefined
  });

  const products = listData?.products || [];

  return (
    <div className="min-h-[100dvh] flex flex-col bg-muted/20 pb-20">
      <Header />
      
      <main className="flex-1 container mx-auto max-w-md p-4 space-y-6">
        <div className="space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search anything in Accra..." 
              className="pl-9 bg-card shadow-sm border-border"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide -mx-4 px-4 snap-x">
            <Button 
              variant={nearby ? "default" : "outline"} 
              size="sm" 
              className={`rounded-full snap-start shrink-0 ${nearby ? 'bg-primary text-primary-foreground' : 'bg-card text-foreground'}`}
              onClick={handleNearbyToggle}
            >
              <MapPin className="h-4 w-4 mr-1" />
              Near Me
            </Button>
            
            {CATEGORIES.map((cat) => {
              const Icon = cat.icon;
              const isActive = category === cat.id;
              return (
                <Button
                  key={cat.id}
                  variant={isActive ? "default" : "outline"}
                  size="sm"
                  className={`rounded-full snap-start shrink-0 ${isActive ? 'bg-primary text-primary-foreground' : 'bg-card text-foreground'}`}
                  onClick={() => setCategory(isActive ? undefined : cat.id)}
                >
                  <Icon className="h-4 w-4 mr-1" />
                  {cat.id}
                </Button>
              )
            })}
          </div>
        </div>

        <div className="space-y-4">
          <h2 className="text-lg font-black tracking-tight">Top Picks For You</h2>
          
          {isLoading ? (
            <div className="grid grid-cols-2 gap-3">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="space-y-2">
                  <Skeleton className="h-32 w-full rounded-xl" />
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                </div>
              ))}
            </div>
          ) : products.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center bg-card rounded-xl border border-dashed border-border p-6">
              <ShoppingBag className="h-12 w-12 text-muted-foreground mb-4 opacity-50" />
              <h3 className="font-semibold text-lg">No items found</h3>
              <p className="text-sm text-muted-foreground mt-1">Try adjusting your search or filters.</p>
              <Button variant="outline" className="mt-4" onClick={() => { setSearch(""); setCategory(undefined); setNearby(false); setCoords(null); }}>
                Clear Filters
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {products.map(product => (
                <Link key={product.id} href={`/product/${product.id}`}>
                  <div className={`group flex flex-col h-full bg-card rounded-xl border shadow-xs overflow-hidden transition-all hover:shadow-md hover:border-primary/50 cursor-pointer ${product.isBoosted ? 'ring-1 ring-amber-400 border-amber-200 dark:border-amber-900/50' : 'border-border'}`}>
                    <div className="relative aspect-square bg-muted/50 w-full overflow-hidden">
                      {product.images && product.images.length > 0 ? (
                        <img 
                          src={product.images[0]} 
                          alt={product.title} 
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-muted">
                          <ShoppingBag className="h-8 w-8 text-muted-foreground opacity-30" />
                        </div>
                      )}
                      
                      {product.isBoosted && (
                        <Badge className="absolute top-2 left-2 bg-amber-500 hover:bg-amber-600 text-white font-bold border-none shadow-sm gap-1 px-1.5">
                          <Zap className="h-3 w-3 fill-current" /> Boosted
                        </Badge>
                      )}
                    </div>
                    
                    <div className="p-3 flex flex-col flex-1">
                      <div className="flex justify-between items-start mb-1">
                        <span className="font-bold text-lg leading-none">{product.currency} {product.price.toLocaleString()}</span>
                      </div>
                      
                      <h3 className="text-sm font-medium leading-tight line-clamp-2 mb-2 text-muted-foreground group-hover:text-foreground transition-colors">{product.title}</h3>
                      
                      <div className="mt-auto pt-2 border-t border-border flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center">
                            <span className="text-[9px] font-bold text-primary">{product.sellerName.charAt(0)}</span>
                          </div>
                          <span className="text-xs font-medium truncate max-w-[80px]">{product.sellerName}</span>
                          {product.sellerVerified && (
                            <ShieldCheck className="h-3.5 w-3.5 text-blue-500 shrink-0" />
                          )}
                        </div>
                      </div>
                      
                      {product.distanceKm !== undefined && product.distanceKm !== null && (
                        <div className="flex items-center mt-1.5 text-[10px] text-muted-foreground font-medium">
                          <MapPin className="h-3 w-3 mr-0.5" />
                          {product.distanceKm.toFixed(1)} km away
                        </div>
                      )}
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </main>
      
      <BottomNav />
    </div>
  );
}