import { useAuth } from "@/lib/auth-context";
import { useUpgradePlan, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Header, BottomNav } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle2, Crown, Loader2, Zap, Star } from "lucide-react";

const PLANS = [
  {
    tier: "free",
    name: "Free",
    price: "0",
    description: "Basic selling features",
    features: ["Post up to 5 items", "Standard visibility", "Basic seller badge"],
    icon: null,
    color: "bg-muted"
  },
  {
    tier: "basic",
    name: "Basic",
    price: "29",
    description: "For casual sellers",
    features: ["Post up to 20 items", "Slightly boosted visibility", "Basic support"],
    icon: Star,
    color: "bg-blue-500"
  },
  {
    tier: "silver",
    name: "Silver",
    price: "79",
    description: "Growing your business",
    features: ["Post up to 100 items", "Higher visibility in search", "Priority support", "Silver seller badge"],
    icon: Zap,
    color: "bg-slate-400"
  },
  {
    tier: "gold",
    name: "Gold",
    price: "199",
    description: "Serious merchants",
    features: ["Unlimited items", "Top visibility in search", "24/7 Priority support", "Gold seller badge", "Analytics dashboard"],
    icon: Crown,
    color: "bg-amber-400"
  },
  {
    tier: "diamond",
    name: "Diamond",
    price: "499",
    description: "Enterprise sellers",
    features: ["Everything in Gold", "Dedicated account manager", "Diamond seller badge", "Featured in marketing", "Zero commission fees"],
    icon: Crown,
    color: "bg-indigo-500"
  }
];

export default function PremiumPage() {
  const { user, refetch } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const upgradePlan = useUpgradePlan();

  if (!user) {
    setLocation("/auth");
    return null;
  }

  const handleUpgrade = (tier: string) => {
    if (tier === user.premiumTier) return;
    
    upgradePlan.mutate({ data: { tier: tier as any } }, {
      onSuccess: () => {
        toast({ title: `Successfully upgraded to ${tier} plan!` });
        queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
        refetch();
      },
      onError: (err: any) => {
        toast({ title: "Upgrade failed", description: err.message, variant: "destructive" });
      }
    });
  };

  return (
    <div className="min-h-[100dvh] flex flex-col bg-muted/20 pb-20">
      <Header />
      
      <main className="flex-1 container mx-auto max-w-md p-4 space-y-6">
        <div className="text-center py-6">
          <Crown className="h-12 w-12 text-amber-500 mx-auto mb-4" />
          <h1 className="text-2xl font-black tracking-tight">Upgrade Your Selling Power</h1>
          <p className="text-muted-foreground mt-2 text-sm">Get more visibility, post more items, and grow your business on YAHOVEL.</p>
        </div>

        <div className="space-y-4">
          {PLANS.map((plan) => {
            const isCurrent = user.premiumTier === plan.tier;
            const Icon = plan.icon;
            
            return (
              <div 
                key={plan.tier} 
                className={`bg-card rounded-2xl border p-5 relative overflow-hidden transition-all ${isCurrent ? 'ring-2 ring-primary border-primary shadow-md' : 'shadow-sm hover:border-primary/50'}`}
              >
                {isCurrent && (
                  <div className="absolute top-0 right-0 bg-primary text-primary-foreground text-[10px] font-bold px-3 py-1 rounded-bl-xl z-10">
                    CURRENT PLAN
                  </div>
                )}
                
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      {Icon && <div className={`p-1.5 rounded-full text-white ${plan.color}`}><Icon className="h-4 w-4" /></div>}
                      <h2 className="text-xl font-bold">{plan.name}</h2>
                    </div>
                    <p className="text-sm text-muted-foreground">{plan.description}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-2xl font-black">GHS {plan.price}</span>
                    <span className="text-xs text-muted-foreground block">/ month</span>
                  </div>
                </div>

                <div className="space-y-2 mb-6">
                  {plan.features.map((feature, i) => (
                    <div key={i} className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-500 shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>

                <Button 
                  className={`w-full font-bold ${isCurrent ? 'bg-muted text-muted-foreground hover:bg-muted cursor-default' : plan.tier === 'free' ? 'bg-secondary text-secondary-foreground hover:bg-secondary/80' : 'bg-primary hover:bg-primary/90'}`}
                  disabled={isCurrent || upgradePlan.isPending}
                  onClick={() => handleUpgrade(plan.tier)}
                >
                  {upgradePlan.isPending && upgradePlan.variables?.data.tier === plan.tier ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  ) : null}
                  {isCurrent ? "Active" : plan.tier === 'free' ? "Downgrade to Free" : `Upgrade to ${plan.name}`}
                </Button>
              </div>
            );
          })}
        </div>
      </main>

      <BottomNav />
    </div>
  );
}