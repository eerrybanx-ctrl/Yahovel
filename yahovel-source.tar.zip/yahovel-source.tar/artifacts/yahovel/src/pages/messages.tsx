import { useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useListChats, getListChatsQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth-context";
import { Header, BottomNav } from "@/components/layout";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ShieldCheck, MessageSquare } from "lucide-react";

function formatWhen(iso: string): string {
  const d = new Date(iso);
  const diff = Date.now() - d.getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h`;
  const days = Math.floor(hrs / 24);
  if (days < 7) return `${days}d`;
  return d.toLocaleDateString();
}

export default function MessagesPage() {
  const { user, isLoading: authLoading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!authLoading && !user) setLocation("/auth");
  }, [authLoading, user, setLocation]);

  const { data, isLoading } = useListChats({
    query: {
      enabled: !!user,
      refetchInterval: 5000,
      queryKey: getListChatsQueryKey(),
    },
  });

  return (
    <div className="min-h-[100dvh] flex flex-col bg-muted/20 pb-20">
      <Header />

      <main className="flex-1 container mx-auto max-w-md p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-black tracking-tight">Messages</h1>
        </div>

        {isLoading ? (
          <div className="space-y-2">
            {[0, 1, 2, 3].map((i) => (
              <div
                key={i}
                className="flex items-center gap-3 p-3 bg-card rounded-xl border"
              >
                <Skeleton className="h-12 w-12 rounded-full" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-1/3" />
                  <Skeleton className="h-3 w-2/3" />
                </div>
              </div>
            ))}
          </div>
        ) : !data || data.chats.length === 0 ? (
          <div className="text-center p-10 bg-card rounded-xl border border-dashed mt-8">
            <MessageSquare className="h-12 w-12 text-muted-foreground/50 mx-auto mb-3" />
            <h2 className="font-bold mb-1">No conversations yet</h2>
            <p className="text-muted-foreground text-sm">
              Tap "Message" on a product to start chatting with a seller.
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {data.chats.map((chat) => (
              <Link key={chat.id} href={`/messages/${chat.id}`}>
                <div className="flex items-center gap-3 p-3 bg-card rounded-xl border shadow-xs hover:border-primary/40 transition-colors cursor-pointer">
                  <Avatar className="h-12 w-12 border">
                    <AvatarImage src={chat.otherUser.profilePicUrl || ""} />
                    <AvatarFallback className="bg-primary/10 text-primary font-bold">
                      {chat.otherUser.name.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="font-semibold text-sm truncate">
                        {chat.otherUser.name}
                      </span>
                      {chat.otherUser.isVerified && (
                        <ShieldCheck className="h-3.5 w-3.5 text-blue-500 shrink-0" />
                      )}
                      {chat.otherUser.premiumTier !== "free" && (
                        <Badge
                          variant="outline"
                          className="text-[9px] capitalize h-4 px-1 border-primary/30 text-primary"
                        >
                          {chat.otherUser.premiumTier}
                        </Badge>
                      )}
                    </div>
                    {chat.product && (
                      <p className="text-[11px] text-primary truncate font-medium">
                        Re: {chat.product.title}
                      </p>
                    )}
                    <p
                      className={`text-xs truncate ${chat.unreadCount > 0 ? "font-semibold text-foreground" : "text-muted-foreground"}`}
                    >
                      {chat.lastMessage
                        ? (chat.lastMessage.senderId === user?.id ? "You: " : "") +
                          chat.lastMessage.body
                        : "Tap to start the conversation"}
                    </p>
                  </div>
                  <div className="flex flex-col items-end gap-1 shrink-0">
                    <span className="text-[10px] text-muted-foreground">
                      {formatWhen(chat.updatedAt)}
                    </span>
                    {chat.unreadCount > 0 && (
                      <Badge className="h-5 min-w-5 px-1.5 rounded-full bg-primary text-primary-foreground text-[10px] font-bold">
                        {chat.unreadCount}
                      </Badge>
                    )}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
}
