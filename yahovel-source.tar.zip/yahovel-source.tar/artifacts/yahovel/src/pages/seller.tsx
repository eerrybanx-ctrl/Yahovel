import { useRoute } from "wouter";
import { useGetUserPublic, getGetUserPublicQueryKey } from "@workspace/api-client-react";
import { Header, BottomNav } from "@/components/layout";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ShieldCheck, Star, MapPin, PackageOpen } from "lucide-react";
import { Link } from "wouter";

export default function SellerProfilePage() {
  const [match, params] = useRoute("/seller/:userId");
  const userId = params?.userId || "";

  const { data: profile, isLoading, error } = useGetUserPublic(userId, {
    query: { enabled: !!userId, queryKey: getGetUserPublicQueryKey(userId) }
  });

  return (
    <div className="min-h-[100dvh] flex flex-col bg-muted/20 pb-20">
      <Header />
      
      <main className="flex-1 container mx-auto max-w-md p-4 space-y-6">
        {isLoading ? (
          <div className="space-y-6">
            <div className="flex flex-col items-center space-y-4 bg-card p-6 rounded-xl border">
              <Skeleton className="h-24 w-24 rounded-full" />
              <Skeleton className="h-6 w-1/2" />
              <Skeleton className="h-4 w-1/3" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              {[1, 2, 3, 4].map(i => (
                <Skeleton key={i} className="h-48 w-full rounded-xl" />
              ))}
            </div>
          </div>
        ) : error || !profile ? (
          <div className="text-center p-8 bg-card rounded-xl border mt-8">
            <h2 className="text-xl font-bold">Seller not found</h2>
            <p className="text-muted-foreground mt-2">This profile might have been removed.</p>
          </div>
        ) : (
          <>
            <div className="bg-card rounded-xl border shadow-sm p-6 text-center relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-16 bg-primary/10"></div>
              
              <Avatar className="h-24 w-24 border-4 border-card shadow-sm mx-auto relative z-10">
                <AvatarImage src={profile.user.profilePicUrl || ""} />
                <AvatarFallback className="text-3xl font-bold bg-primary text-primary-foreground">
                  {profile.user.name.charAt(0)}
                </AvatarFallback>
              </Avatar>
              
              <div className="mt-4 space-y-2">
                <div className="flex items-center justify-center gap-1.5">
                  <h1 className="text-2xl font-black">{profile.user.name}</h1>
                  {profile.user.isVerified && <ShieldCheck className="h-5 w-5 text-blue-500" />}
                </div>
                
                <p className="text-sm text-muted-foreground">@{profile.user.username}</p>
                
                <div className="flex items-center justify-center gap-4 text-sm font-medium pt-2">
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-amber-500 fill-current mr-1" />
                    <span>{profile.user.rating.toFixed(1)}</span>
                    <span className="text-muted-foreground ml-1">({profile.user.reviewCount})</span>
                  </div>
                  {profile.user.city && (
                    <div className="flex items-center text-muted-foreground">
                      <MapPin className="h-4 w-4 mr-1" />
                      {profile.user.city}
                    </div>
                  )}
                </div>
                
                {profile.user.bio && (
                  <p className="text-sm mt-4 text-muted-foreground italic">"{profile.user.bio}"</p>
                )}
                
                <div className="pt-4 flex justify-center">
                  <Badge variant="outline" className="capitalize text-xs font-bold border-primary/20 text-primary">
                    {profile.user.premiumTier !== 'free' ? `${profile.user.premiumTier} Seller` : 'Seller'}
                  </Badge>
                </div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-bold text-lg">Active Listings</h2>
                <Badge variant="secondary">{profile.products.length}</Badge>
              </div>

              {profile.products.length === 0 ? (
                <div className="text-center p-8 bg-card rounded-xl border border-dashed">
                  <PackageOpen className="h-12 w-12 text-muted-foreground/50 mx-auto mb-3" />
                  <p className="text-muted-foreground text-sm">No active listings right now.</p>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-3">
                  {profile.products.map(product => (
                    <Link key={product.id} href={`/product/${product.id}`}>
                      <div className="group h-full flex flex-col bg-card rounded-xl border shadow-xs overflow-hidden transition-all hover:shadow-md hover:border-primary/50 cursor-pointer">
                        <div className="relative aspect-square bg-muted w-full overflow-hidden">
                          {product.images && product.images.length > 0 ? (
                            <img src={product.images[0]} alt={product.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-muted-foreground opacity-30">
                              <PackageOpen className="h-8 w-8" />
                            </div>
                          )}
                        </div>
                        <div className="p-3 flex flex-col flex-1">
                          <span className="font-bold text-base leading-none mb-1">{product.currency} {product.price.toLocaleString()}</span>
                          <h3 className="text-xs font-medium line-clamp-2 text-muted-foreground">{product.title}</h3>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </>
        )}
      </main>

      <BottomNav />
    </div>
  );
}