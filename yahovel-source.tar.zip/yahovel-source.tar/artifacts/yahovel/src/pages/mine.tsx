import { useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useListMyProducts, useDeleteProduct, useBoostProduct, getListMyProductsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Header, BottomNav } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Trash2, Zap, PackageOpen, Loader2 } from "lucide-react";
import { useLocation } from "wouter";

export default function MinePage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: listData, isLoading } = useListMyProducts({
    query: { enabled: !!user, queryKey: getListMyProductsQueryKey() }
  });

  const deleteProduct = useDeleteProduct();
  const boostProduct = useBoostProduct();

  const [boostId, setBoostId] = useState<string | null>(null);
  const [boostHours, setBoostHours] = useState("24");

  if (!user) {
    setLocation("/auth");
    return null;
  }

  const products = listData?.products || [];

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this item?")) {
      deleteProduct.mutate({ productId: id }, {
        onSuccess: () => {
          toast({ title: "Product deleted" });
          queryClient.invalidateQueries({ queryKey: getListMyProductsQueryKey() });
        }
      });
    }
  };

  const handleBoost = () => {
    if (!boostId) return;
    boostProduct.mutate({ productId: boostId, data: { durationHours: Number(boostHours) } }, {
      onSuccess: () => {
        toast({ title: "Product boosted successfully!" });
        setBoostId(null);
        queryClient.invalidateQueries({ queryKey: getListMyProductsQueryKey() });
      },
      onError: (err: any) => {
        toast({ title: "Failed to boost", description: err.message, variant: "destructive" });
      }
    });
  };

  return (
    <div className="min-h-[100dvh] flex flex-col bg-muted/20 pb-20">
      <Header />
      
      <main className="flex-1 container mx-auto max-w-md p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-black">My Items</h1>
          <Badge variant="outline">{products.length} Active</Badge>
        </div>

        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <Skeleton key={i} className="h-24 w-full rounded-xl" />
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center bg-card rounded-xl border border-dashed border-border p-6">
            <PackageOpen className="h-12 w-12 text-muted-foreground mb-4 opacity-50" />
            <h3 className="font-semibold text-lg">No items yet</h3>
            <p className="text-sm text-muted-foreground mt-1">Post your first item to start selling.</p>
            <Button className="mt-4 font-bold" onClick={() => setLocation("/post")}>Post an Item</Button>
          </div>
        ) : (
          <div className="space-y-3">
            {products.map(product => (
              <div key={product.id} className={`flex gap-3 bg-card p-3 rounded-xl border shadow-sm ${product.isBoosted ? 'border-amber-300 ring-1 ring-amber-300/50' : 'border-border'}`}>
                <div className="w-20 h-20 bg-muted rounded-md overflow-hidden shrink-0">
                  {product.images && product.images.length > 0 ? (
                    <img src={product.images[0]} alt={product.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center"><PackageOpen className="h-6 w-6 text-muted-foreground/30" /></div>
                  )}
                </div>
                
                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start">
                      <h3 className="font-semibold text-sm line-clamp-1">{product.title}</h3>
                      {product.isBoosted && <Badge className="bg-amber-500 hover:bg-amber-600 text-[9px] px-1 py-0 h-4">BOOSTED</Badge>}
                    </div>
                    <span className="font-bold text-primary">{product.currency} {product.price.toLocaleString()}</span>
                  </div>
                  
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-xs text-muted-foreground">{product.viewCount} views</span>
                    <div className="flex gap-2">
                      <Button variant="outline" size="icon" className="h-7 w-7 text-destructive border-destructive/20 hover:bg-destructive/10" onClick={() => handleDelete(product.id)} disabled={deleteProduct.isPending}>
                        <Trash2 className="h-3 w-3" />
                      </Button>
                      {!product.isBoosted && (
                        <Button size="sm" className="h-7 px-2 text-xs font-bold bg-amber-500 hover:bg-amber-600 text-white" onClick={() => setBoostId(product.id)}>
                          <Zap className="h-3 w-3 mr-1 fill-current" /> Boost
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      <Dialog open={!!boostId} onOpenChange={(open) => !open && setBoostId(null)}>
        <DialogContent className="w-[90vw] max-w-md rounded-xl">
          <DialogHeader>
            <DialogTitle>Boost Item</DialogTitle>
            <DialogDescription>Get more views by pinning this item to the top of the marketplace.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Duration (Hours)</Label>
              <Input type="number" min="1" max="168" value={boostHours} onChange={e => setBoostHours(e.target.value)} />
            </div>
            <p className="text-xs text-muted-foreground">Boosting will cost GHS {(Number(boostHours) * 5).toFixed(2)}</p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBoostId(null)}>Cancel</Button>
            <Button onClick={handleBoost} className="bg-amber-500 hover:bg-amber-600 text-white font-bold" disabled={boostProduct.isPending}>
              {boostProduct.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Zap className="h-4 w-4 mr-2 fill-current" />}
              Pay & Boost
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <BottomNav />
    </div>
  );
}