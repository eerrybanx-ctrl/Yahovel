import { useEffect, useState, useRef } from "react";
import { useAuth } from "@/lib/auth-context";
import { useListOnlineRiders, useUpdateRider, getListOnlineRidersQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Header, BottomNav } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { Loader2, Navigation, Power, PowerOff } from "lucide-react";

// Fix leaflet icon issue
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const getVehicleColor = (vehicle: string) => {
  switch (vehicle) {
    case 'moto': return '#3b82f6'; // blue
    case 'car': return '#f97316'; // orange
    case 'bicycle': return '#22c55e'; // green
    case 'truck': return '#a855f7'; // purple
    default: return '#64748b'; // gray
  }
};

const createCustomIcon = (vehicle: string) => {
  const color = getVehicleColor(vehicle);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="${color}" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-8 h-8"><circle cx="12" cy="12" r="10"></circle></svg>`;
  
  return L.divIcon({
    html: svg,
    className: 'bg-transparent border-none',
    iconSize: [32, 32],
    iconAnchor: [16, 16],
    popupAnchor: [0, -16]
  });
};

function MapUpdater({ center }: { center: [number, number] }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, map.getZoom());
  }, [center, map]);
  return null;
}

export default function RidersPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [center, setCenter] = useState<[number, number]>([5.6037, -0.1870]); // Accra default
  const [hasUserLoc, setHasUserLoc] = useState(false);
  const [onlineMode, setOnlineMode] = useState(user?.riderOnline || false);
  const locationWatchId = useRef<number | null>(null);

  const { data: ridersData, isLoading } = useListOnlineRiders(
    { lat: center[0], lng: center[1] },
    {
      query: {
        refetchInterval: 15000,
        queryKey: getListOnlineRidersQueryKey({ lat: center[0], lng: center[1] }),
      },
    } // Refetch every 15s
  );

  const updateRider = useUpdateRider();

  useEffect(() => {
    if (navigator.geolocation && !hasUserLoc) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setCenter([pos.coords.latitude, pos.coords.longitude]);
          setHasUserLoc(true);
        },
        () => {
          // ignore error, keep default
        }
      );
    }
  }, [hasUserLoc]);

  // Rider tracking logic
  useEffect(() => {
    if (onlineMode && user?.isRider) {
      if (navigator.geolocation) {
        locationWatchId.current = navigator.geolocation.watchPosition(
          (pos) => {
            updateRider.mutate({
              data: {
                online: true,
                lat: pos.coords.latitude,
                lng: pos.coords.longitude
              }
            });
          },
          (err) => {
            toast({ title: "Location error", description: err.message, variant: "destructive" });
            setOnlineMode(false);
          },
          { enableHighAccuracy: true, maximumAge: 10000, timeout: 5000 }
        );
      }
    } else {
      if (locationWatchId.current !== null) {
        navigator.geolocation.clearWatch(locationWatchId.current);
        locationWatchId.current = null;
      }
      if (!onlineMode && user?.isRider) {
        updateRider.mutate({ data: { online: false } });
      }
    }

    return () => {
      if (locationWatchId.current !== null) {
        navigator.geolocation.clearWatch(locationWatchId.current);
      }
    };
  }, [onlineMode, user?.isRider]);

  const toggleOnline = () => {
    if (!onlineMode) {
      // Go online
      if (!navigator.geolocation) {
        toast({ title: "Geolocation not supported", variant: "destructive" });
        return;
      }
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          updateRider.mutate({
            data: { online: true, lat: pos.coords.latitude, lng: pos.coords.longitude }
          }, {
            onSuccess: () => {
              setOnlineMode(true);
              toast({ title: "You are now online" });
            }
          });
        },
        (err) => {
          toast({ title: "Need location permission to go online", variant: "destructive" });
        }
      );
    } else {
      // Go offline
      updateRider.mutate({ data: { online: false } }, {
        onSuccess: () => {
          setOnlineMode(false);
          toast({ title: "You are now offline" });
        }
      });
    }
  };

  const riders = ridersData?.riders || [];

  return (
    <div className="min-h-[100dvh] flex flex-col bg-muted/20 pb-20 relative">
      <Header />
      
      <main className="flex-1 w-full relative z-0">
        <MapContainer center={center} zoom={13} className="w-full h-[calc(100vh-120px)] z-0">
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <MapUpdater center={center} />
          
          {hasUserLoc && (
            <Marker position={center} icon={L.divIcon({
              html: `<div class="w-4 h-4 bg-primary rounded-full border-2 border-white shadow-md animate-pulse"></div>`,
              className: 'bg-transparent border-none'
            })}>
              <Popup>You are here</Popup>
            </Marker>
          )}

          {riders.map(rider => {
            // Don't show current user's marker if they are a rider to avoid clutter
            if (rider.id === user?.id) return null;
            return (
              <Marker 
                key={rider.id} 
                position={[rider.lat, rider.lng]} 
                icon={createCustomIcon(rider.vehicle)}
              >
                <Popup className="rounded-xl overflow-hidden">
                  <div className="p-1 min-w-[150px]">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="h-8 w-8 bg-muted rounded-full overflow-hidden">
                        {rider.profilePicUrl ? (
                          <img src={rider.profilePicUrl} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full bg-primary/20 flex items-center justify-center text-primary font-bold">
                            {rider.name.charAt(0)}
                          </div>
                        )}
                      </div>
                      <div>
                        <h4 className="font-bold leading-tight">{rider.name}</h4>
                        <p className="text-xs text-muted-foreground capitalize">{rider.vehicle}</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between text-xs mt-2 border-t pt-2">
                      <span className="font-medium text-amber-600">★ {rider.rating.toFixed(1)}</span>
                      <a href={`tel:${rider.phone}`} className="text-primary font-bold">Call</a>
                    </div>
                  </div>
                </Popup>
              </Marker>
            );
          })}
        </MapContainer>

        {/* Floating Rider Toggle */}
        {user?.isRider && (
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-[1000]">
            <Button 
              size="lg" 
              onClick={toggleOnline}
              disabled={updateRider.isPending}
              className={`rounded-full shadow-xl px-8 font-black text-sm transition-all duration-300 ${
                onlineMode 
                  ? 'bg-destructive hover:bg-destructive/90 text-white border-2 border-white' 
                  : 'bg-primary hover:bg-primary/90 text-white border-2 border-white'
              }`}
            >
              {updateRider.isPending ? (
                <Loader2 className="h-5 w-5 animate-spin mr-2" />
              ) : onlineMode ? (
                <PowerOff className="h-5 w-5 mr-2" />
              ) : (
                <Power className="h-5 w-5 mr-2" />
              )}
              {onlineMode ? "GO OFFLINE" : "GO ONLINE"}
            </Button>
          </div>
        )}

        {/* Loading Indicator */}
        {isLoading && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-background/80 backdrop-blur px-4 py-2 rounded-full shadow-sm text-xs font-medium z-[1000] flex items-center">
            <Loader2 className="h-3 w-3 animate-spin mr-2" /> Locating riders...
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
}