import { useState, useEffect } from "react";
import { useAuth } from "@/lib/auth-context";
import { useUpdateMe, useUpdateRider, useLogout, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Header, BottomNav } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { Loader2, MapPin, LogOut, Crown, CheckCircle2 } from "lucide-react";

export default function ProfilePage() {
  const { user, refetch } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const updateMe = useUpdateMe();
  const updateRider = useUpdateRider();
  const logout = useLogout();

  const [name, setName] = useState("");
  const [bio, setBio] = useState("");
  const [profilePicUrl, setProfilePicUrl] = useState("");
  const [city, setCity] = useState("");
  const [coords, setCoords] = useState<{lat: number, lng: number} | null>(null);
  
  const [isRider, setIsRider] = useState(false);
  const [vehicle, setVehicle] = useState<any>("");

  const [gettingLoc, setGettingLoc] = useState(false);

  useEffect(() => {
    if (user) {
      setName(user.name || "");
      setBio(user.bio || "");
      setProfilePicUrl(user.profilePicUrl || "");
      setCity(user.city || "");
      if (user.lat && user.lng) {
        setCoords({ lat: user.lat, lng: user.lng });
      }
      setIsRider(user.isRider || false);
      setVehicle(user.riderVehicle || "");
    }
  }, [user]);

  if (!user) {
    setLocation("/auth");
    return null;
  }

  const handleGetLocation = () => {
    setGettingLoc(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setGettingLoc(false);
        toast({ title: "Location updated" });
      },
      (err) => {
        setGettingLoc(false);
        toast({ title: "Could not get location", variant: "destructive" });
      }
    );
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateMe.mutate({
      data: {
        name,
        bio,
        profilePicUrl,
        city,
        lat: coords?.lat,
        lng: coords?.lng
      }
    }, {
      onSuccess: () => {
        toast({ title: "Profile updated" });
        queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
        refetch();
      }
    });
  };

  const handleSaveRider = (e: React.FormEvent) => {
    e.preventDefault();
    if (isRider && !vehicle) {
      toast({ title: "Please select a vehicle type", variant: "destructive" });
      return;
    }
    
    updateRider.mutate({
      data: {
        isRider,
        vehicle: isRider ? vehicle : undefined
      }
    }, {
      onSuccess: () => {
        toast({ title: "Rider settings updated" });
        queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
        refetch();
      }
    });
  };

  const handleLogout = () => {
    logout.mutate(undefined, {
      onSuccess: () => {
        queryClient.clear();
        refetch();
        setLocation("/");
      }
    });
  };

  return (
    <div className="min-h-[100dvh] flex flex-col bg-muted/20 pb-20">
      <Header />
      
      <main className="flex-1 container mx-auto max-w-md p-4 space-y-6">
        <div className="flex items-center gap-4 bg-card p-4 rounded-xl border shadow-sm">
          <Avatar className="h-16 w-16 border-2 border-primary/20">
            <AvatarImage src={user.profilePicUrl || ""} />
            <AvatarFallback className="text-xl font-bold bg-primary text-primary-foreground">{user.name.charAt(0)}</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <div className="flex items-center gap-1.5">
              <h2 className="text-xl font-black">{user.name}</h2>
              {user.isVerified && <CheckCircle2 className="h-4 w-4 text-blue-500" />}
            </div>
            <p className="text-sm text-muted-foreground">@{user.username}</p>
            <div className="mt-1 flex gap-2">
              <Badge variant="outline" className={`text-[10px] uppercase font-bold ${user.premiumTier !== 'free' ? 'border-amber-500 text-amber-500' : ''}`}>
                {user.premiumTier}
              </Badge>
              {user.isRider && <Badge variant="secondary" className="text-[10px] uppercase font-bold">Rider</Badge>}
            </div>
          </div>
        </div>

        <form onSubmit={handleSaveProfile} className="bg-card p-4 rounded-xl border shadow-sm space-y-4">
          <h3 className="font-bold text-lg border-b pb-2">Edit Profile</h3>
          
          <div className="space-y-2">
            <Label>Full Name</Label>
            <Input value={name} onChange={e => setName(e.target.value)} required />
          </div>
          
          <div className="space-y-2">
            <Label>Bio</Label>
            <Textarea value={bio} onChange={e => setBio(e.target.value)} placeholder="Tell buyers about yourself" className="min-h-[80px]" />
          </div>
          
          <div className="space-y-2">
            <Label>Profile Picture URL</Label>
            <Input value={profilePicUrl} onChange={e => setProfilePicUrl(e.target.value)} placeholder="https://..." />
          </div>

          <div className="space-y-2">
            <Label>City</Label>
            <Input value={city} onChange={e => setCity(e.target.value)} placeholder="Accra" />
          </div>
          
          <div className="space-y-2 pt-2">
            <Button type="button" variant="outline" size="sm" className="w-full text-xs" onClick={handleGetLocation} disabled={gettingLoc}>
              {gettingLoc ? <Loader2 className="h-3 w-3 animate-spin mr-2" /> : <MapPin className="h-3 w-3 mr-2" />}
              {coords ? "Location Pinned ✓" : "Update My Exact Location"}
            </Button>
          </div>

          <Button type="submit" className="w-full mt-2" disabled={updateMe.isPending}>
            {updateMe.isPending && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
            Save Profile
          </Button>
        </form>

        <form onSubmit={handleSaveRider} className="bg-card p-4 rounded-xl border shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b pb-2 mb-2">
            <h3 className="font-bold text-lg">Rider Settings</h3>
            <Switch checked={isRider} onCheckedChange={setIsRider} />
          </div>
          
          <p className="text-sm text-muted-foreground">Turn on to appear on the live rider map and accept delivery jobs.</p>
          
          {isRider && (
            <div className="space-y-2 pt-2 animate-in slide-in-from-top-2">
              <Label>Vehicle Type</Label>
              <Select value={vehicle} onValueChange={setVehicle}>
                <SelectTrigger>
                  <SelectValue placeholder="Select vehicle" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="moto">Motorcycle</SelectItem>
                  <SelectItem value="car">Car</SelectItem>
                  <SelectItem value="bicycle">Bicycle</SelectItem>
                  <SelectItem value="truck">Truck / Van</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          <Button type="submit" variant={isRider ? "default" : "secondary"} className="w-full mt-2" disabled={updateRider.isPending}>
            {updateRider.isPending && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
            Save Rider Status
          </Button>
        </form>

        <div className="bg-card p-4 rounded-xl border shadow-sm flex items-center justify-between">
          <div>
            <h3 className="font-bold">Premium Plan</h3>
            <p className="text-xs text-muted-foreground capitalize">Current: {user.premiumTier}</p>
          </div>
          <Button variant="outline" className="border-amber-500 text-amber-500 hover:bg-amber-50 dark:hover:bg-amber-950/30" onClick={() => setLocation("/premium")}>
            <Crown className="h-4 w-4 mr-2" /> Upgrade
          </Button>
        </div>

        <Button variant="destructive" className="w-full font-bold" onClick={handleLogout} disabled={logout.isPending}>
          {logout.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <LogOut className="h-4 w-4 mr-2" />}
          Sign Out
        </Button>
      </main>

      <BottomNav />
    </div>
  );
}