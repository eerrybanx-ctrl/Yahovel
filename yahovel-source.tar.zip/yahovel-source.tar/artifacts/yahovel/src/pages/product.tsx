import { useRoute, useLocation } from "wouter";
import { useGetProduct, useOpenChat, getGetProductQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth-context";
import { Header, BottomNav } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { MapPin, ShieldCheck, Star, Clock, Zap, MessageSquare, PhoneCall } from "lucide-react";
import { Link } from "wouter";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";

export default function ProductPage() {
  const [match, params] = useRoute("/product/:id");
  const id = params?.id || "";
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();

  const { data: product, isLoading, error } = useGetProduct(id, {
    query: { enabled: !!id, queryKey: getGetProductQueryKey(id) }
  });

  const openChat = useOpenChat();

  const onMessageSeller = () => {
    if (!user) {
      setLocation("/auth");
      return;
    }
    if (!product) return;
    if (product.sellerId === user.id) {
      toast({ title: "This is your listing." });
      return;
    }
    openChat.mutate(
      { data: { otherUserId: product.sellerId, productId: product.id } },
      {
        onSuccess: (chat) => setLocation(`/messages/${chat.id}`),
        onError: () =>
          toast({
            title: "Could not open chat",
            description: "Please try again.",
            variant: "destructive",
          }),
      },
    );
  };

  return (
    <div className="min-h-[100dvh] flex flex-col bg-muted/20 pb-20">
      <Header />
      
      <main className="flex-1 container mx-auto max-w-md bg-card min-h-full pb-safe">
        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-72 w-full rounded-none" />
            <div className="p-4 space-y-4">
              <Skeleton className="h-8 w-1/3" />
              <Skeleton className="h-6 w-2/3" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <div className="flex gap-2">
                <Skeleton className="h-10 flex-1" />
                <Skeleton className="h-10 flex-1" />
              </div>
            </div>
          </div>
        ) : error || !product ? (
          <div className="p-8 text-center flex flex-col items-center justify-center min-h-[50vh]">
            <h2 className="text-xl font-bold mb-2">Product not found</h2>
            <p className="text-muted-foreground mb-6">This item may have been removed.</p>
            <Link href="/">
              <Button>Back to Marketplace</Button>
            </Link>
          </div>
        ) : (
          <div className="flex flex-col">
            <div className="relative aspect-[4/3] bg-muted w-full overflow-hidden flex items-center justify-center">
              {product.images && product.images.length > 0 ? (
                <img 
                  src={product.images[0]} 
                  alt={product.title} 
                  className="w-full h-full object-cover" 
                />
              ) : (
                <div className="text-muted-foreground">No image</div>
              )}
              {product.isBoosted && (
                <Badge className="absolute top-3 left-3 bg-amber-500 hover:bg-amber-600 text-white gap-1 py-1 px-2 text-sm shadow-md border-none">
                  <Zap className="h-4 w-4 fill-current" /> BOOSTED
                </Badge>
              )}
            </div>
            
            <div className="p-4 border-b">
              <div className="flex justify-between items-start mb-2">
                <h1 className="text-2xl font-bold tracking-tight text-primary leading-none">
                  {product.currency} {product.price.toLocaleString()}
                </h1>
                <Badge variant="outline" className="font-medium bg-muted/50">{product.condition}</Badge>
              </div>
              <h2 className="text-lg font-medium leading-tight mb-3 text-foreground/90">{product.title}</h2>
              
              <div className="flex flex-wrap gap-y-2 gap-x-4 text-xs text-muted-foreground">
                <span className="flex items-center">
                  <Clock className="h-3.5 w-3.5 mr-1" />
                  {new Date(product.createdAt).toLocaleDateString()}
                </span>
                {product.city && (
                  <span className="flex items-center">
                    <MapPin className="h-3.5 w-3.5 mr-1" />
                    {product.city}
                  </span>
                )}
                <span className="flex items-center">
                  <Badge variant="secondary" className="text-[10px] h-5 rounded-sm px-1.5">{product.category}</Badge>
                </span>
              </div>
            </div>

            <div className="p-4 border-b space-y-3">
              <h3 className="font-bold text-sm uppercase tracking-wider text-muted-foreground">Description</h3>
              <p className="text-sm leading-relaxed whitespace-pre-wrap">{product.description}</p>
            </div>

            <div className="p-4 bg-muted/10">
              <Link href={`/seller/${product.sellerId}`}>
                <div className="flex items-center justify-between p-3 bg-card rounded-xl border shadow-sm cursor-pointer hover:border-primary/50 transition-colors">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-12 w-12 border">
                      <AvatarFallback className="bg-primary/10 text-primary font-bold text-lg">
                        {product.sellerName.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-sm">{product.sellerName}</span>
                        {product.sellerVerified && <ShieldCheck className="h-4 w-4 text-blue-500" />}
                      </div>
                      <div className="flex items-center text-xs text-muted-foreground mt-0.5">
                        <Star className="h-3 w-3 text-amber-500 fill-current mr-1" />
                        <span className="font-medium text-foreground mr-1">{product.sellerRating.toFixed(1)}</span>
                        <span>({product.viewCount} views)</span>
                      </div>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-[10px] capitalize font-bold">
                    {product.sellerPremiumTier !== 'free' ? product.sellerPremiumTier : 'Seller'}
                  </Badge>
                </div>
              </Link>
            </div>
            
            <div className="p-4 pt-2 flex gap-3 sticky bottom-0 bg-card border-t z-10 pb-6">
              <Button
                className="flex-1 font-bold shadow-sm"
                size="lg"
                onClick={onMessageSeller}
                disabled={openChat.isPending}
              >
                <MessageSquare className="h-4 w-4 mr-2" />
                {openChat.isPending ? "Opening..." : "Message Seller"}
              </Button>
              <Button variant="outline" className="flex-1 font-bold shadow-sm border-primary/20 text-primary hover:bg-primary/5" size="lg">
                <PhoneCall className="h-4 w-4 mr-2" /> Call Seller
              </Button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}