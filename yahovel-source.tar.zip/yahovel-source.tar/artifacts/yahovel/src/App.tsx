import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/lib/auth-context";
import NotFound from "@/pages/not-found";

import HomePage from "@/pages/home";
import AuthPage from "@/pages/auth";
import ProductPage from "@/pages/product";
import PostPage from "@/pages/post";
import MinePage from "@/pages/mine";
import RidersPage from "@/pages/riders";
import SellerProfilePage from "@/pages/seller";
import PremiumPage from "@/pages/premium";
import ProfilePage from "@/pages/profile";
import MessagesPage from "@/pages/messages";
import ChatPage from "@/pages/chat";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    },
  },
});

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/product/:id" component={ProductPage} />
      <Route path="/post" component={PostPage} />
      <Route path="/mine" component={MinePage} />
      <Route path="/riders" component={RidersPage} />
      <Route path="/seller/:userId" component={SellerProfilePage} />
      <Route path="/premium" component={PremiumPage} />
      <Route path="/profile" component={ProfilePage} />
      <Route path="/messages" component={MessagesPage} />
      <Route path="/messages/:chatId" component={ChatPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
