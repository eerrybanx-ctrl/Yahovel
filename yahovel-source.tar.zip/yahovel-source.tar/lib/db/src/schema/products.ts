import {
  pgTable,
  text,
  timestamp,
  boolean,
  doublePrecision,
  integer,
  uuid,
} from "drizzle-orm/pg-core";
import { usersTable } from "./users";

export const productsTable = pgTable("products", {
  id: uuid("id").primaryKey().defaultRandom(),
  sellerId: uuid("seller_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  price: doublePrecision("price").notNull(),
  currency: text("currency").notNull().default("GHS"),
  category: text("category").notNull(),
  condition: text("condition").notNull().default("new"),
  images: text("images").array().notNull().default([]),
  city: text("city"),
  lat: doublePrecision("lat"),
  lng: doublePrecision("lng"),
  isBoosted: boolean("is_boosted").notNull().default(false),
  boostedUntil: timestamp("boosted_until", { withTimezone: true }),
  viewCount: integer("view_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type ProductRow = typeof productsTable.$inferSelect;
