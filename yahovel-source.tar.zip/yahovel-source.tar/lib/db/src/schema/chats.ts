import {
  pgTable,
  text,
  timestamp,
  uuid,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { productsTable } from "./products";

export const chatsTable = pgTable(
  "chats",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    // Canonical ordering: userAId < userBId (lexicographic) so we can enforce uniqueness per pair+product.
    userAId: uuid("user_a_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    userBId: uuid("user_b_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    productId: uuid("product_id").references(() => productsTable.id, {
      onDelete: "set null",
    }),
    lastMessageAt: timestamp("last_message_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => ({
    pairProductIdx: uniqueIndex("chats_pair_product_idx").on(
      t.userAId,
      t.userBId,
      t.productId,
    ),
    userAIdx: index("chats_user_a_idx").on(t.userAId),
    userBIdx: index("chats_user_b_idx").on(t.userBId),
  }),
);

export const messagesTable = pgTable(
  "messages",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    chatId: uuid("chat_id")
      .notNull()
      .references(() => chatsTable.id, { onDelete: "cascade" }),
    senderId: uuid("sender_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    body: text("body").notNull(),
    readAt: timestamp("read_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => ({
    chatIdx: index("messages_chat_idx").on(t.chatId, t.createdAt),
  }),
);

export type ChatRow = typeof chatsTable.$inferSelect;
export type MessageRow = typeof messagesTable.$inferSelect;
