import {
  pgTable,
  text,
  timestamp,
  boolean,
  doublePrecision,
  integer,
  uuid,
} from "drizzle-orm/pg-core";

export const usersTable = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  phone: text("phone").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  bio: text("bio"),
  profilePicUrl: text("profile_pic_url"),
  city: text("city"),
  lat: doublePrecision("lat"),
  lng: doublePrecision("lng"),
  isVerified: boolean("is_verified").notNull().default(false),
  premiumTier: text("premium_tier").notNull().default("free"),
  premiumExpiresAt: timestamp("premium_expires_at", { withTimezone: true }),
  isRider: boolean("is_rider").notNull().default(false),
  riderVehicle: text("rider_vehicle"),
  riderOnline: boolean("rider_online").notNull().default(false),
  riderLat: doublePrecision("rider_lat"),
  riderLng: doublePrecision("rider_lng"),
  riderLastSeenAt: timestamp("rider_last_seen_at", { withTimezone: true }),
  themePreference: text("theme_preference").notNull().default("dark"),
  rating: doublePrecision("rating").notNull().default(0),
  reviewCount: integer("review_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type UserRow = typeof usersTable.$inferSelect;
